<?php
include 'db.php'; // Bao gồm file kết nối CSDL để sử dụng biến $conn

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy thông tin từ form
    $mssv = $_POST['mssv'];
    $name = $_POST['name'];

    // Chuẩn bị câu truy vấn SQL để chèn dữ liệu vào bảng students
    $sql = "INSERT INTO students (mssv, name) VALUES ('$mssv', '$name')";

    if ($conn->query($sql) === TRUE) {
        echo "Thêm sinh viên thành công!";
    } else {
        echo "Lỗi: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm sinh viên</title>
</head>
<body>
    <h2>Nhập thông tin sinh viên</h2>
    <form action="index.php" method="POST">
        MSSV: <input type="text" name="mssv" required><br><br>
        Họ tên: <input type="text" name="name" required><br><br>
        <input type="submit" value="Thêm sinh viên">
    </form>

    <h2>Danh sách sinh viên</h2>
    <table border="1">
        <tr>
            <th>MSSV</th>
            <th>Họ tên</th>
        </tr>

        <?php
        // Truy vấn danh sách sinh viên từ CSDL
        $sql = "SELECT mssv, name FROM students";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Hiển thị từng hàng dữ liệu
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row["mssv"] . "</td><td>" . $row["name"] . "</td></tr>";
            }
        } else {
            echo "<tr><td colspan='2'>Chưa có sinh viên nào.</td></tr>";
        }

        $conn->close();
        ?>
    </table>
</body>
</html>
